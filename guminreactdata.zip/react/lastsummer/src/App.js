/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import React from 'react'; /*리액트*/
import 'bootstrap/dist/css/bootstrap.min.css';/*부트스트랩*/
/*import Sidebar from './Sidebar/Sidebar';sidebar.js */
import './App.css';/*App.css*/
import './Sidebar/argon-dashboard.css';/*argon-dashboard.css*/
import img from './assets/mascot.png';
import img2 from './assets/mainbode.png';
import img3 from './assets/icon.png';
import img4 from './assets/logo.png';
import img5 from './assets/humidity.png';
import img6 from './assets/temperature.png';
import img7 from './assets/Good.png';

function App() {
  return (
  <body className="g-sidenav-show   bg-gray-100">
  <div className="min-height-150 bg-primary position-absolute w-100"></div>
  <aside className="sidenav bg-white navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-4 " id="sidenav-main">
    <div className="sidenav-header">
      <i className="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a className="navbar-brand m-0" target="_blank">
        <img src={img3}></img>
        <span className="ms-1 font-weight-bold w-10 test1" style={{fontSize: 20}}>LastSummer</span>
      </a>
    </div>

    <hr className="horizontal dark mt-0"></hr>
    <div className="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
      <ul className="navbar-nav">
        <li className="nav-item">
          <a className="nav-link active">
            <div className="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                <img src={img} className="mascot"  style={{ display: 'inline-block', height: '30px' }} ></img>{/*이미지:mascot */}
            </div>
            <span className="nav-link-text ms-1 w-10 test1"  style={{fontSize: 20}}>대시보드</span>
          </a>
        </li>
        
        <li className="nav-item">
          <a className="nav-link " >
            <div className="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-camera" viewBox="0 0 16 16">
                <path d="M15 12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h1.172a3 3 0 0 0 2.12-.879l.83-.828A1 1 0 0 1 6.827 3h2.344a1 1 0 0 1 .707.293l.828.828A3 3 0 0 0 12.828 5H14a1 1 0 0 1 1 1v6zM2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4H2z" />
                <path d="M8 11a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5zm0 1a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM3 6.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z" />
              </svg>
            </div>
            <span className="nav-link-text ms-1 w-10 test1"  style={{fontSize: 20}}>사진페이지</span>
          </a>
        </li>
        
        <li className="nav-item">
          <a className="nav-link ">
            <div className="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-heart-fill" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z" />
              </svg>
            </div>
            <span className="nav-link-text ms-1 w-10 test1" style={{fontSize: 20}}>질병페이지</span>
          </a>
        </li>
       
        <li className="nav-item">
          <a className="nav-link " >
            <div className="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-camera-reels-fill" viewBox="0 0 16 16">
                <path d="M6 3a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                <path d="M9 6a3 3 0 1 1 0-6 3 3 0 0 1 0 6z" />
                <path d="M9 6h.5a2 2 0 0 1 1.983 1.738l3.11-1.382A1 1 0 0 1 16 7.269v7.462a1 1 0 0 1-1.406.913l-3.111-1.382A2 2 0 0 1 9.5 16H2a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h7z" />
              </svg>
            </div>
            <span className="nav-link-text ms-1 w-10 test1" style={{fontSize: 20}}>영상페이지</span>
          </a>
        </li>
      </ul>
    </div>
    <div className=" test1 position-absolute top-100 start-50 translate-middle" style={{marginTop: -13, width:200}} >
    <button type="button" className="btn btn-success w-100  mb-2" style={{marginTop: -100, fontSize: 15}}>로그아웃</button>
  </div>
  </aside>

  <main className="main-content position-relative border-radius-lg ">
    <nav className="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl " id="navbarBlur"
      data-scroll="false">
      <div className="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb"></nav>
        <div className="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar"></div>
      </div>
    </nav>
  </main>.

    <div style={{ height: '2.2rem' }}>
    <img src={img2} className="mainbode" style={{top:'-30px', display: 'inline-block', position: 'relative', margin: '0 0 -10px 1400px', height: '70px', zIndex: 1 }}></img>
    </div>

    <div style={{ height: '10rem', width:'1250px',marginLeft: '270px'}}>
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <h6 class="w-10 test1" style={{fontSize: 20}}>대시보드</h6>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center justify-content-center mb-0">
                  
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>  
</div>

    <div class="div-left test1" style={{ width: '500px'}}>
    <button type="button" class="btn w-100 my-1 mb-2 test1" style={{backgroundColor:'#BAD98B', display: 'inline-block', position: 'relative',fontSize:'23px', zIndex: 1,right:'-11rem',}}>모 니 터 링</button>
    </div>

    <div class="div-right test1" style={{ width: '500px'}}>
    <button type="button" class="btn w-100 my-1 mb-2 test1" style={{ backgroundColor:'#BAD98B', display: 'inline-block', position: 'relative', fontSize:'23px', zIndex: 1,left:'11rem' }}>사 진</button>
    </div>

    <div class="container-fluid py-4" style={{float:'left'}}>
    <div style={{height:'3rem;'}}></div>
    
    <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4" style={{width:'500px', height:'400px', margin:'0 0 0 850px', zIndex: 1 }} >
                <div class="card" style={{width:'1200px;', height:'350px;',margin:'0 0 0 90px',zIndex: 1 }}>
                  <div class="card-body p-3" >
                      <div class="col-8">
                          <div class="numbers">
                          <img src={img4} style={{zIndex:1}}></img>{/*onclick="location.href='picture.html';추가 예정*/}
                          </div>
                      </div>
                </div>
              </div>
              <div class="right test1" style={{Right:'0.01px;'}}>
                <button type="button" class="btn bg-gradient-info w-auto my-4 mb-2 " style={{fontSize: '17px',margin:'0 0 0 380px' ,zIndex: 1 }}>영상 만들기</button>
              </div>
            </div>
            
            <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4" style={{marginTop: '-400px',marginLeft: '360px', width:' 400px', height:'100px',zIndex: 1}} >
                  <div class="card">
                    <div class="card-body p-3" style={{width:'400px',height:' 100px'}}>
                      <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                              <p class=" mb-0 text-uppercase font-weight-bold w-30 test1" style={{fontSize:20}}>온도</p>
                              <p class="test1">온도 테스트입니다°C</p>
                            </div>
                        </div>
                      <div class="col-4 text-end">

                    <img src={img6}style={{width:'50',height:'50',fill:'currentColor'}}></img>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <br/>
                <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4" style={{marginLeft: '360px', width:' 400px', height:'100px',zIndex: 1}} >
                  <div class="card">
                    <div class="card-body p-3" style={{width:'400px',height:' 100px'}}>
                      <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                              <p class=" mb-0 text-uppercase font-weight-bold w-30 test1" style={{fontSize:20}}>습도</p>
                              <p class="test1">습도 테스트입니다%</p>
                            </div>
                        </div>
                      <div class="col-4 text-end">
                    <img src={img5} style={{width:'50',height:'50',fill:'currentColor'}}></img>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <br/>

              <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4"style={{marginLeft: '360px', width:' 400px', height:'100px',zIndex: 1}}>
                  <div class="card">
                    <div class="card-body p-3" style={{width:'400px',height:' 100px'}}>
                      <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                              <p class=" mb-0 text-uppercase font-weight-bold w-30 test1" style={{fontSize:20}}>작물 질병</p>
                            </div>
                        </div>
                      <div class="col-4 text-end">
                        <img src={img7} style={{width:'50',height:'50',fill:'currentColor'}}></img>
                      </div>
                    </div>
                  </div>
                </div>
              </div>











    </div>
  </body>
);
}

export default App;