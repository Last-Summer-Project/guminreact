import React from "react";
import './argon-dashboard.css';/*argon-dashboard.css*/

const Sidebar = () => {
    return(
        <div classNAme="Sidebar">
            <div classNAme="Sidebar-ul">
            <ul>
                <li>대시보드</li>
                <li classNAme=".Sidebar-no">사진페이지</li>
                <li classNAme=".Sidebar-no">질병페이지</li>
                <li classNAme=".Sidebar-no">영상페이지</li>
            </ul>
            </div>
        </div> 
    );
}

export default Sidebar;